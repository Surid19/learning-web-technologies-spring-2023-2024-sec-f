<?php

header('location: view/sign-in.php');